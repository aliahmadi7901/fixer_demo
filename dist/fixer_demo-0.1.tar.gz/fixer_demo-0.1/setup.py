from setuptools import setup

setup(name='fixer_demo',
      version='0.1',
      description='fixer service demo package',
      author='ali',
      license='MIT',
      packages=['fixer'],
      zip_safe=False)
